//
//  Office.swift
//  vtb_hackathon
//
//  Created by fact boi on 13.10.2023.
//

import CoreLocation

struct Office: Codable {
    let salePointName, address: String
    let status: Status
    let openHours: [OpenHour]
    let rko: Rko?
    let openHoursIndividual: [OpenHour]
    let officeType: String
    let salePointFormat: SalePointFormat
    let suoAvailability, hasRamp: HasRamp?
    let latitude, longitude: Double
    let metroStation: String?
    let distance: Int
    let kep: Bool?
    let myBranch: Bool
    let salePointCode: String?
}

enum HasRamp: String, Codable {
    case n = "N"
    case y = "Y"
}

// MARK: - OpenHour
struct OpenHour: Codable {
    let days: Days
    let hours: Hours?
}

enum Days: String, Codable {
    case cб = "cб"
    case cбВс = "cб,вс"
    case в = "в"
    case вс = "вс"
    case вт = "вт"
    case неОбслуживаетФЛ = "Не обслуживает ФЛ"
    case неОбслуживаетЮЛ = "Не обслуживает ЮЛ"
    case перерыв = "перерыв"
    case пн = "пн"
    case пнПт = "пн-пт"
    case пнЧт = "пн-чт"
    case пт = "пт"
    case сб = "сб"
    case сбВс = "сб,вс"
    case ср = "ср"
    case чт = "чт"
}

enum Hours: String, Codable {
    case the09001600 = "09:00-16:00"
    case the09001645 = "09:00-16:45"
    case the09001700 = "09:00-17:00"
    case the09001800 = "09:00-18:00"
    case the09001900 = "09:00-19:00"
    case the09002000 = "09:00-20:00"
    case the09002100 = "09:00-21:00"
    case the09301530 = "09:30-15:30"
    case the09301600 = "09:30-16:00"
    case the09302000 = "09:30-20:00"
    case the10001500 = "10:00-15:00"
    case the10001600 = "10:00-16:00"
    case the10001700 = "10:00-17:00"
    case the10001800 = "10:00-18:00"
    case the10001900 = "10:00-19:00"
    case the10002000 = "10:00-20:00"
    case the10002100 = "10:00-21:00"
    case the10002200 = "10:00-22:00"
    case the11001600 = "11:00-16:00"
    case the14151500 = "14:15-15:00"
    case выходной = "выходной"
}

enum Rko: String, Codable {
    case естьРКО = "есть РКО"
    case нетРКО = "нет РКО"
}

enum SalePointFormat: String, Codable {
    case брокер = "Брокер"
    case корпоративный = "Корпоративный"
    case микро23 = "Микро 2(3)"
    case микроРБ = "Микро (РБ)"
    case миниРасш = "Мини_расш"
    case праймРБ = "Прайм (РБ)"
    case привилегияРБ = "Привилегия (РБ)"
    case розничныйРБ = "Розничный (РБ)"
    case стандарт = "Стандарт"
    case стандартБизнесОтдел = "Стандарт+бизнес отдел"
    case универсальный = "Универсальный"
    case филиал = "Филиал"
}

enum Status: String, Codable {
    case открытая = "открытая"
}

extension Office: BankFacility {
  var location: CLLocation {
    return CLLocation(latitude: latitude, longitude: longitude)
  }

  var type: BankFacilityType {
    return .office
  }
}
