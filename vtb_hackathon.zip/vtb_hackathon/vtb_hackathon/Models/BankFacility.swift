//
//  BankFacility.swift
//  vtb_hackathon
//
//  Created by fact boi on 14.10.2023.
//

import CoreLocation
import MapKit

protocol BankFacility {
  var address: String { get }
  var type: BankFacilityType { get }
  var location: CLLocation { get }

}

enum BankFacilityType: String {
  case atm = "Банкомат"
  case office = "Отделение"
}
