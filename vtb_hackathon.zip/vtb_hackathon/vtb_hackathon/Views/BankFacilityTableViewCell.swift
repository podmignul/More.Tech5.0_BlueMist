//
//  BankFacilityTableViewCell.swift
//  vtb_hackathon
//
//  Created by fact boi on 14.10.2023.
//

import UIKit

final class BankFacilityTableViewCell: UITableViewCell {
  private let logoImageView = UIImageView(image: #imageLiteral(resourceName: "logo"))
  private let label = UILabel()

  override func layoutSubviews() {
    addLogoImageView()
    addLabel()
  }

  public func configure(with bankFacility: BankFacility) {
    label.text = bankFacility.address
  }

  private func addLogoImageView() {
    addSubview(logoImageView)
    logoImageView.pin.left(16).vCenter()
  }

  private func addLabel() {
    addSubview(label)
    label.pin.after(of: logoImageView, aligned: .center).left(16).right(16)
  }

}
