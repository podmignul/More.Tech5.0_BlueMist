//
//  BankFacilitiesViewController.swift
//  vtb_hackathon
//
//  Created by fact boi on 14.10.2023.
//

import UIKit
import PinLayout
import UBottomSheet

protocol BankFacilitiesViewControllerDelegate: AnyObject {
  func bankFacilitiesDidLoad(_ bankFacilities: [BankFacility])
  func filterButtonDidClicked(_ currentFacilityType: BankFacilityType)
  func bankFacilitiesTypeDidChanged(_ bankFacilities: [BankFacility], type: BankFacilityType)
  func didSelectFacility(_ facility: BankFacility)
}

final class BankFacilitiesViewController: UIViewController {
  private let tableView = UITableView(frame: .zero, style: .insetGrouped)
  private let search = UISearchController(searchResultsController: nil)

  private let atmLoader: AtmLoader
  private let officeLoader: OfficeLoader

  private var bankFacilities: [BankFacility] = []
  private var filteredFacilities: [BankFacility] = []

  public var sheetCoordinator: UBottomSheetCoordinator?

  public var currentFacilityType: BankFacilityType = .atm {
    didSet {
      filteredFacilities = bankFacilities.filter { $0.type == currentFacilityType }
      title = currentFacilityType.rawValue
      delegate?.bankFacilitiesTypeDidChanged(filteredFacilities, type: currentFacilityType)
      tableView.reloadData()
    }
  }

  public weak var delegate: BankFacilitiesViewControllerDelegate?

  init(atmLoader: AtmLoader, officeLoader: OfficeLoader) {
    self.atmLoader = atmLoader
    self.officeLoader = officeLoader
    super.init(nibName: nil, bundle: nil)
  }

  private func populateArray() {
    atmLoader.loadAtms { atms in
      self.bankFacilities.append(contentsOf: atms)
      self.filteredFacilities = atms
    }

    officeLoader.loadOffices { offices in
      self.bankFacilities.append(contentsOf: offices)
    }

    delegate?.bankFacilitiesDidLoad(bankFacilities)

  }

  required init?(coder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }

  override func viewDidLoad() {
    super.viewDidLoad()
    populateArray()
    configureTableView()
    configureNavigationBar()
  }

  override func viewWillLayoutSubviews() {
    addTableView()
  }

  override func viewWillAppear(_ animated: Bool) {
    sheetCoordinator?.startTracking(item: self)
  }

  private func configureTableView() {
    tableView.delegate = self
    tableView.dataSource = self
    tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
  }

  private func addTableView() {
    view.addSubview(tableView)
    tableView.pin.all()
  }

  private func configureNavigationBar() {
    title = currentFacilityType.rawValue
    search.searchResultsUpdater = self
    search.obscuresBackgroundDuringPresentation = false
    search.searchBar.placeholder = "Type something here to search"
    navigationItem.searchController = search
    navigationItem.rightBarButtonItem = UIBarButtonItem(image: UIImage(systemName: "slider.horizontal.3"), style: .done, target: self, action: #selector(handleFilterButtonClicked(_:)))
  }

  @objc private func handleFilterButtonClicked(_ sender: UIBarButtonItem) {
    delegate?.filterButtonDidClicked(currentFacilityType)
  }

}

extension BankFacilitiesViewController: UITableViewDataSource {
  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return filteredFacilities.count
  }

  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
    let bankFacility = filteredFacilities[indexPath.row]
    cell.imageView?.image = UIImage(named: "logo")
    cell.textLabel?.text = bankFacility.address
    return cell
  }
}

extension BankFacilitiesViewController: UITableViewDelegate {
  func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    delegate?.didSelectFacility(filteredFacilities[indexPath.row])
  }
}

extension BankFacilitiesViewController: UISearchResultsUpdating {
  func updateSearchResults(for searchController: UISearchController) {

  }
}

extension BankFacilitiesViewController: Draggable {
  func draggableView() -> UIScrollView? {
    return tableView
  }
}
