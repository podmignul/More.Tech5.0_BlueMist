//
//  ViewController.swift
//  vtb_hackathon
//
//  Created by fact boi on 12.10.2023.
//

import UIKit
import MapKit
import PinLayout
import UBottomSheet

final class MapViewController: UIViewController {
  private let segmentedControl = UISegmentedControl(items: [BankFacilityType.atm.rawValue, BankFacilityType.office.rawValue])
  private let bankFacilitiesViewController = BankFacilitiesViewController(atmLoader: LocalAtmLoader(), officeLoader: LocalOfficeLoader())
  private let filterButton = UIButton()
  private let mapView = MKMapView()
  private let chatButton = UIButton()
  private var sheetCoordinator: UBottomSheetCoordinator!

  let initialLocation = CLLocation(latitude: 55.753930, longitude: 37.620795)
  lazy var meAnnotation = MKPointAnnotation(__coordinate: CLLocationCoordinate2D(location: initialLocation), title: "Я", subtitle: nil)

  var currentPlacemark: CLPlacemark?
  var optimalLocation: CLLocationCoordinate2D?

  public override func viewDidLoad() {
    super.viewDidLoad()

    mapView.centerToLocation(initialLocation)
    mapView.addAnnotation(meAnnotation)
    bankFacilitiesViewController.delegate = self
    bankFacilitiesViewController.currentFacilityType = .atm


    //    let request = MKDirections.Request()
    //    request.source = MKMapItem(placemark: MKPlacemark(coordinate: CLLocationCoordinate2D(location: initialLocation)))
    //    request.destination = MKMapItem(placemark: MKPlacemark(coordinate:CLLocationCoordinate2D(location: optimalLocation)))
    //    request.transportType = .automobile
    //
    //    let directions = MKDirections(request: request)
    //    directions.calculate { response, error in
    //      if let route = response?.routes.first {
    //        self.mapView.addOverlay(route.polyline)
    //      }
    //    }

  }

  public override func viewWillLayoutSubviews() {
    super.viewWillLayoutSubviews()
    configureMapView()
    configureSegmentedControl()

    guard sheetCoordinator == nil else { return }
    sheetCoordinator = UBottomSheetCoordinator(parent: self,
                                               delegate: self)
    let navigationViewController = UINavigationController(rootViewController: bankFacilitiesViewController)
    bankFacilitiesViewController.sheetCoordinator = sheetCoordinator
    sheetCoordinator.addSheet(navigationViewController, to: self) { container in
      let f = self.view.frame
      let rect = CGRect(x: f.minX, y: f.minY, width: f.width, height: f.height)
      container.roundCorners(corners: [.topLeft, .topRight], radius: 16, rect: rect)
    }
    sheetCoordinator.setCornerRadius(10)

    chatButton.backgroundColor = #colorLiteral(red: 0, green: 0.6666666667, blue: 1, alpha: 1)
    chatButton.tintColor = .white
    chatButton.setImage(UIImage(systemName: "message"), for: .normal)
    chatButton.addTarget(self, action: #selector(chatButtonClicked(_:)), for: .touchUpInside)
    view.addSubview(chatButton)
    chatButton.pin.height(64).width(64).bottom(16).right(16)
    chatButton.round()

  }

  @objc private func chatButtonClicked(_ sender: UIButton) {
    let chatViewController = ChatViewController()
    chatViewController.modalPresentationStyle = .fullScreen
    present(chatViewController, animated: true)
  }

  private func configureMapView() {
    mapView.delegate = self
    view.addSubview(mapView)
    mapView.pin.all()
  }

  private func configureSegmentedControl() {
    segmentedControl.addTarget(self, action: #selector(handleSegmentedControlValueChanged(_:)), for: .valueChanged)
    segmentedControl.backgroundColor = .black
    segmentedControl.selectedSegmentTintColor = #colorLiteral(red: 0, green: 0.6666666667, blue: 1, alpha: 1)
    segmentedControl.selectedSegmentIndex = 0
    segmentedControl.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.white], for: .normal)
    view.addSubview(segmentedControl)
    segmentedControl.pin.width(90%).hCenter().top(view.pin.safeArea.top)
  }

  private func drawFacilitiesOnMap(_ facilities: [BankFacility]) {
    mapView.removeAnnotations(mapView.annotations)
    facilities.forEach { facility in
      let annotation = MKPointAnnotation()
      annotation.title = "VTB"
      annotation.coordinate = CLLocationCoordinate2D(location: facility.location)
      mapView.addAnnotation(annotation)
    }
    mapView.addAnnotation(meAnnotation)
  }

  @objc private func handleSegmentedControlValueChanged(_ sender: UISegmentedControl) {
    if bankFacilitiesViewController.currentFacilityType == .atm {
      bankFacilitiesViewController.currentFacilityType = .office
    } else {
      bankFacilitiesViewController.currentFacilityType = .atm
    }

    mapView.removeOverlays(mapView.overlays)
  }

  func loadDirections() {
    guard let end = optimalLocation else {
      return
    }

    let source = MKPlacemark(coordinate: CLLocationCoordinate2D(location: initialLocation))
    let destination = MKPlacemark(coordinate: end)

    let directionRequest = MKDirections.Request()
    directionRequest.source = MKMapItem(placemark: source)
    directionRequest.destination = MKMapItem(placemark: destination)
    directionRequest.transportType = .walking

    let directions = MKDirections(request: directionRequest)
    directions.calculate { response, error in
      guard let response = response else {
        return
      }

      let route = response.routes.first!
      self.mapView.addOverlay(route.polyline, level: .aboveRoads)
    }
  }

}

extension MapViewController: MKMapViewDelegate {
  func mapView(_ mapView: MKMapView, didSelect annotation: MKAnnotation) {
    print(annotation.coordinate)
  }

  func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
    let renderer = MKPolylineRenderer(overlay: overlay)
    renderer.strokeColor = #colorLiteral(red: 0, green: 0.6666666667, blue: 1, alpha: 1)
    renderer.lineWidth = 4
    return renderer
  }

  func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
    let identifier = "MyAnnotation"

    if annotation.isKind(of: MKUserLocation.self) {
      return nil
    }

    var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier) as? MKMarkerAnnotationView

    if annotationView == nil {
      annotationView = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: identifier)
    }

    if annotation.title == "Я" {
      annotationView?.markerTintColor = .red
      annotationView?.glyphImage = UIImage(systemName: "person.fill")
    } else {
      annotationView?.markerTintColor = #colorLiteral(red: 0, green: 0.6666666667, blue: 1, alpha: 1)
      annotationView?.glyphImage = #imageLiteral(resourceName: "logo")
    }

    return annotationView
  }
}



extension MapViewController: UBottomSheetCoordinatorDelegate {

}

extension MapViewController: BankFacilitiesViewControllerDelegate {
  func didSelectFacility(_ facility: BankFacility) {

  }

  func bankFacilitiesTypeDidChanged(_ bankFacilities: [BankFacility], type: BankFacilityType) {
    drawFacilitiesOnMap(bankFacilities)
  }

  func filterButtonDidClicked(_ currentFacilityType: BankFacilityType) {
    let storyboard = UIStoryboard(name: "Filters", bundle: nil)

    switch currentFacilityType {
    case .atm:
      let atmViewController = storyboard.instantiateViewController(withIdentifier: "AtmViewController")
      atmViewController.modalPresentationStyle = .fullScreen
      present(atmViewController, animated: true)
    case .office:
      let officeViewController = storyboard.instantiateViewController(withIdentifier: "OfficeViewController")
      officeViewController.modalPresentationStyle = .fullScreen
      present(officeViewController, animated: true)
    }
  }

  func bankFacilitiesDidLoad(_ bankFacilities: [BankFacility]) {
    bankFacilities.forEach { bankFacility in
      let annotation = MKPointAnnotation()
      annotation.title = "VTB"
      annotation.coordinate = CLLocationCoordinate2D(location: bankFacility.location)
      mapView.addAnnotation(annotation)
    }

    optimalLocation = CLLocationCoordinate2D(latitude: 55.757887, longitude: 37.612414)
    loadDirections()
  }
}


