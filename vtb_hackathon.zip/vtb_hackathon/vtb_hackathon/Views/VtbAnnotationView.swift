//
//  VtbAnnotationView.swift
//  vtb_hackathon
//
//  Created by fact boi on 14.10.2023.
//

import MapKit

final class VtbAnnotationView: MKAnnotationView {

}

