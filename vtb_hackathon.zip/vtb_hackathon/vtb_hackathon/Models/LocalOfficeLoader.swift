//
//  LocalOfficeLoader.swift
//  vtb_hackathon
//
//  Created by fact boi on 13.10.2023.
//

import Foundation
import SwiftyJSON

final class LocalOfficeLoader: OfficeLoader {

  private let jsonDecoder = JSONDecoder()
  private let url = Bundle.main.url(forResource: "offices", withExtension: "json")!

  func loadOffices(completion: @escaping ([Office]) -> Void) {
    let data = try! Data(contentsOf: url)
    let offices = try! jsonDecoder.decode([Office].self, from: data)
    completion(offices)
  }
}
