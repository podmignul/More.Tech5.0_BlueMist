//
//  LocalAtmLoader.swift
//  vtb_hackathon
//
//  Created by fact boi on 13.10.2023.
//

import Foundation
import SwiftyJSON

final class LocalAtmLoader: AtmLoader {

  private let url = Bundle.main.url(forResource: "atms", withExtension: "json")!
  private let jsonDecoder = JSONDecoder()

  func loadAtms(completion: @escaping ([ATM]) -> Void) {
    let data = try! Data(contentsOf: url)
    let json = JSON(data)
    let atmsArray = try! json["atms"].rawData()
    let atms = try! jsonDecoder.decode([ATM].self, from: atmsArray)
    completion(atms)
  }
}
