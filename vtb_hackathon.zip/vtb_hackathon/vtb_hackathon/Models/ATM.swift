//
//  ATM.swift
//  vtb_hackathon
//
//  Created by fact boi on 12.10.2023.
//

import CoreLocation

//MARK: - ATM
struct ATM: Codable {
    let address: String
    let latitude, longitude: Double
    let allDay: Bool
    let services: Services
}

// MARK: - Services
struct Services: Codable {
    let wheelchair, blind, nfcForBankCards, qrRead: Blind
    let supportsUsd, supportsChargeRub, supportsEur, supportsRub: Blind
}

// MARK: - Blind
struct Blind: Codable {
    let serviceCapability: ServiceCapability
    let serviceActivity: ServiceActivity
}

enum ServiceActivity: String, Codable {
    case available = "AVAILABLE"
    case unavailable = "UNAVAILABLE"
    case unknown = "UNKNOWN"
}

enum ServiceCapability: String, Codable {
    case supported = "SUPPORTED"
    case unknown = "UNKNOWN"
    case unsupported = "UNSUPPORTED"
}

extension ATM: BankFacility {
  var location: CLLocation {
    return CLLocation(latitude: latitude, longitude: longitude)
  }

  var type: BankFacilityType {
    return .atm
  }
}
