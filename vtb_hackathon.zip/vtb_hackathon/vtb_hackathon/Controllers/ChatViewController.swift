import UIKit
import PinLayout

struct ChatMessage {
  let text: String
  let isIncoming: Bool
  let date: Date
}

extension Date {
  static func dateFromCustomString(customString: String) -> Date {
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "MM/dd/yyyy"
    return dateFormatter.date(from: customString) ?? Date()
  }

  func reduceToMonthDayYear() -> Date {
    let calendar = Calendar.current
    let month = calendar.component(.month, from: self)
    let day = calendar.component(.day, from: self)
    let year = calendar.component(.year, from: self)
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "MM/dd/yyyy"
    return dateFormatter.date(from: "\(month)/\(day)/\(year)") ?? Date()
  }
}

class ChatViewController: UITableViewController {

  fileprivate let cellId = "id123"

  let messagesFromServer = [
    ChatMessage(text: "Как открыть счет в ВТБ?", isIncoming: false, date: Date()),
    ChatMessage(text: "Для открытия счета в ВТБ, посетите ближайшее отделение банка с паспортом и ИНН", isIncoming: true, date: Date()),
    ChatMessage(text: "Могу ли я открыть сберегательный счет в ВТБ?", isIncoming: false, date: Date()),
    ChatMessage(text: "Да, в ВТБ вы можете открыть сберегательный счет для накоплений", isIncoming: true, date: Date())
  ]

  fileprivate func attemptToAssembleGroupedMessages() {
    print("Attempt to group our messages together based on Date property")

    let groupedMessages = Dictionary(grouping: messagesFromServer) { (element) -> Date in
      return element.date.reduceToMonthDayYear()
    }

    // provide a sorting for your keys somehow
    let sortedKeys = groupedMessages.keys.sorted()
    sortedKeys.forEach { (key) in
      let values = groupedMessages[key]
      chatMessages.append(values ?? [])
    }

  }

  let closeButton = UIButton(type: .system)
  var chatMessages = [[ChatMessage]]()

  override func viewDidLoad() {
    super.viewDidLoad()

    attemptToAssembleGroupedMessages()
    closeButton.addTarget(self, action: #selector(closeButtonClicked(_:)), for: .touchUpInside)
    navigationItem.title = "Чат Бот"
    navigationController?.navigationBar.prefersLargeTitles = true

    tableView.register(ChatMessageTableViewCell.self, forCellReuseIdentifier: cellId)
    tableView.separatorStyle = .none
    tableView.backgroundColor = UIColor(white: 0.95, alpha: 1)
  }

  @objc private func closeButtonClicked(_ sender: UIButton) {
    dismiss(animated: true)
  }

  override func viewWillLayoutSubviews() {
    let textField = UITextField()
    textField.placeholder = "Введите запрос"
    let sendButton = UIButton(type: .system)
    sendButton.setTitle("Отправить", for: .normal)

    let stackView = UIStackView(arrangedSubviews: [textField, sendButton])
    stackView.axis = .horizontal


    let toolBar = UIView(frame: .zero)
    view.addSubview(toolBar)
    toolBar.pin.left().right().bottom(view.pin.safeArea.bottom).height(144)

    toolBar.addSubview(stackView)
    stackView.pin.all(PEdgeInsets(top: 0, left: 16, bottom: 0, right: 16))


    view.addSubview(closeButton)
    closeButton.pin.top(16).right(16).width(32).height(32)
    closeButton.setImage(UIImage(systemName: "xmark.circle.fill"), for: .normal)
  }

  @objc func sendButtonTapped() {
    // Обработка нажатия кнопки "Отправить"
  }

  override func numberOfSections(in tableView: UITableView) -> Int {
    return chatMessages.count
  }

  class DateHeaderLabel: UILabel {

    override init(frame: CGRect) {
      super.init(frame: frame)

      backgroundColor = .black
      textColor = .white
      textAlignment = .center
      translatesAutoresizingMaskIntoConstraints = false // enables auto layout
      font = UIFont.boldSystemFont(ofSize: 14)
    }

    required init?(coder aDecoder: NSCoder) {
      fatalError("init(coder:) has not been implemented")
    }

    override var intrinsicContentSize: CGSize {
      let originalContentSize = super.intrinsicContentSize
      let height = originalContentSize.height + 12
      layer.cornerRadius = height / 2
      layer.masksToBounds = true
      return CGSize(width: originalContentSize.width + 20, height: height)
    }

  }

  override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
    if let firstMessageInSection = chatMessages[section].first {
      let dateFormatter = DateFormatter()
      dateFormatter.dateFormat = "MM/dd/yyyy"
      let dateString = dateFormatter.string(from: firstMessageInSection.date)

      let label = DateHeaderLabel()
      label.text = dateString

      let containerView = UIView()

      containerView.addSubview(label)
      label.centerXAnchor.constraint(equalTo: containerView.centerXAnchor).isActive = true
      label.centerYAnchor.constraint(equalTo: containerView.centerYAnchor).isActive = true

      return containerView

    }
    return nil
  }

  override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
    return 50
  }

  override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return chatMessages[section].count
  }

  override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let cell = tableView.dequeueReusableCell(withIdentifier: cellId, for: indexPath) as! ChatMessageTableViewCell
    let chatMessage = chatMessages[indexPath.section][indexPath.row]
    cell.chatMessage = chatMessage
    return cell
  }

  override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    tableView.deselectRow(at: indexPath, animated: true)
  }
}
