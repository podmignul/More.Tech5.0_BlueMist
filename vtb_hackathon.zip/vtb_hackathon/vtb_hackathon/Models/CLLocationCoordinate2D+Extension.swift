//
//  CLLocationCoordinate2D+Extension.swift
//  vtb_hackathon
//
//  Created by fact boi on 14.10.2023.
//

import CoreLocation

extension CLLocationCoordinate2D {
  init(location: CLLocation) {
    self.init()
    self.latitude = location.coordinate.latitude
    self.longitude = location.coordinate.longitude
  }
}
