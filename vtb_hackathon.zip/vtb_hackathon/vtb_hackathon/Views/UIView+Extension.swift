//
//  UIView+Extension.swift
//  vtb_hackathon
//
//  Created by fact boi on 14.10.2023.
//

import UIKit

extension UIView{
  func roundCorners(corners: UIRectCorner, radius: CGFloat, rect: CGRect) {
    let path = UIBezierPath(roundedRect: rect, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
    let mask = CAShapeLayer()
    mask.path = path.cgPath
    layer.mask = mask
  }

  func round() {
    layer.cornerRadius = bounds.width / 2
    clipsToBounds = true
  }
}

