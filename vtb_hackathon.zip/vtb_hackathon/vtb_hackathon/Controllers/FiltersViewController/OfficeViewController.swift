//
//  OfficeViewController.swift
//  vtb_hackathon
//
//  Created by fact boi on 14.10.2023.
//

import UIKit

final class OfficeViewController: UIViewController {
  override func viewDidLoad() {
    super.viewDidLoad()
  }
  
  @IBAction private func closeButtonClicked(_ sender: UIButton) {
    dismiss(animated: true)
  }
  
}
